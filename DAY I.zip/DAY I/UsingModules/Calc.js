var calc = require('./Math').Addition;

console.log('The addition is : ' + calc(20,30));